package com.example.android.startngtask2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvLikesDislikesHobbies;
    ListView list;
    String [] arrayLikesDislikesHobbies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLikesDislikesHobbies = findViewById(R.id.tvLikesDislikesHobbies);

        list = findViewById(R.id.listView);

        arrayLikesDislikesHobbies = getResources().getStringArray(R.array.arrayLikesDislikesHobbies);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayLikesDislikesHobbies);

        list.setAdapter(adapter);
    }
}
